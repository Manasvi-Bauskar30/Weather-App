import React from 'react';
import { WeatherData } from '../types/weather';
import { Droplets, Wind, Thermometer } from 'lucide-react';

interface WeatherCardProps {
  weather: WeatherData;
  unit: 'C' | 'F';
  onUnitToggle: () => void;
}

export const WeatherCard: React.FC<WeatherCardProps> = ({ weather, unit, onUnitToggle }) => {
  const convertTemp = (temp: number) => {
    if (unit === 'F') {
      return Math.round((temp * 9/5) + 32);
    }
    return temp;
  };

  const getWeatherIconUrl = (icon: string) => {
    return `https://openweathermap.org/img/wn/${icon}@2x.png`;
  };

  return (
    <div className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl p-8 max-w-md w-full transform transition-all duration-500 hover:scale-105">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-1">
          {weather.name}, {weather.country}
        </h2>
        <p className="text-gray-600 capitalize text-lg">
          {weather.description}
        </p>
      </div>

      <div className="flex items-center justify-center mb-6">
        <img
          src={getWeatherIconUrl(weather.icon)}
          alt={weather.description}
          className="w-20 h-20"
        />
        <div className="ml-4">
          <div className="flex items-baseline">
            <span className="text-5xl font-bold text-gray-800">
              {convertTemp(weather.temperature)}
            </span>
            <button
              onClick={onUnitToggle}
              className="ml-2 text-2xl text-blue-600 hover:text-blue-800 transition-colors duration-200 cursor-pointer"
            >
              °{unit}
            </button>
          </div>
          <p className="text-gray-600 text-sm">
            Feels like {convertTemp(weather.feelsLike)}°{unit}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-blue-50 rounded-lg p-4 flex items-center">
          <Droplets className="w-6 h-6 text-blue-600 mr-3" />
          <div>
            <p className="text-gray-600 text-sm">Humidity</p>
            <p className="font-semibold text-gray-800">{weather.humidity}%</p>
          </div>
        </div>
        <div className="bg-green-50 rounded-lg p-4 flex items-center">
          <Wind className="w-6 h-6 text-green-600 mr-3" />
          <div>
            <p className="text-gray-600 text-sm">Wind Speed</p>
            <p className="font-semibold text-gray-800">{weather.windSpeed} km/h</p>
          </div>
        </div>
      </div>
    </div>
  );
};