import React from 'react';
import { Cloud } from 'lucide-react';

export const LoadingSpinner: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center p-8">
      <div className="relative">
        <Cloud className="w-16 h-16 text-blue-500 animate-bounce" />
        <div className="absolute inset-0 animate-pulse">
          <Cloud className="w-16 h-16 text-blue-300" />
        </div>
      </div>
      <p className="mt-4 text-gray-600 text-lg">Fetching weather data...</p>
    </div>
  );
};