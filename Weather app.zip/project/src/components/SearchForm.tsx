import React, { useState } from 'react';
import { Search, MapPin, Clock } from 'lucide-react';

interface SearchFormProps {
  onSearch: (city: string) => void;
  isLoading: boolean;
  recentSearches: string[];
  onRecentSearchClick: (city: string) => void;
}

export const SearchForm: React.FC<SearchFormProps> = ({ 
  onSearch, 
  isLoading, 
  recentSearches, 
  onRecentSearchClick 
}) => {
  const [city, setCity] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (city.trim()) {
      onSearch(city.trim());
      setCity('');
    }
  };

  return (
    <div className="w-full max-w-md mb-8">
      <form onSubmit={handleSubmit} className="relative mb-4">
        <div className="relative">
          <MapPin className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            value={city}
            onChange={(e) => setCity(e.target.value)}
            placeholder="Enter city name..."
            className="w-full pl-12 pr-4 py-4 rounded-2xl border-2 border-gray-200 focus:border-blue-500 focus:outline-none transition-colors duration-200 text-lg"
            disabled={isLoading}
          />
        </div>
        <button
          type="submit"
          disabled={isLoading || !city.trim()}
          className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white p-3 rounded-xl transition-colors duration-200 disabled:cursor-not-allowed"
        >
          <Search className="w-5 h-5" />
        </button>
      </form>

      {recentSearches.length > 0 && (
        <div className="bg-white/80 backdrop-blur-sm rounded-xl p-4 shadow-lg">
          <div className="flex items-center mb-3">
            <Clock className="w-4 h-4 text-gray-600 mr-2" />
            <span className="text-sm font-medium text-gray-700">Recent Searches</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {recentSearches.map((search, index) => (
              <button
                key={index}
                onClick={() => onRecentSearchClick(search)}
                className="px-3 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm rounded-full transition-colors duration-200"
              >
                {search}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};