export interface WeatherData {
  name: string;
  country: string;
  temperature: number;
  description: string;
  icon: string;
  humidity: number;
  windSpeed: number;
  feelsLike: number;
}

export interface WeatherError {
  message: string;
  code?: string;
}