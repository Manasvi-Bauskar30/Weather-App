import { useState, useCallback } from 'react';
import { WeatherData, WeatherError } from '../types/weather';
import { WeatherService } from '../services/weatherService';

export const useWeather = () => {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<WeatherError | null>(null);
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    const saved = localStorage.getItem('weather-recent-searches');
    return saved ? JSON.parse(saved) : [];
  });

  const searchWeather = useCallback(async (city: string) => {
    setLoading(true);
    setError(null);
    
    try {
      const data = await WeatherService.getCurrentWeather(city);
      const formattedWeather = WeatherService.formatWeatherData(data);
      setWeather(formattedWeather);
      
      // Update recent searches
      const updatedSearches = [city, ...recentSearches.filter(s => s !== city)].slice(0, 5);
      setRecentSearches(updatedSearches);
      localStorage.setItem('weather-recent-searches', JSON.stringify(updatedSearches));
    } catch (err) {
      setError({
        message: err instanceof Error ? err.message : 'An unexpected error occurred'
      });
      setWeather(null);
    } finally {
      setLoading(false);
    }
  }, [recentSearches]);

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  return {
    weather,
    loading,
    error,
    recentSearches,
    searchWeather,
    clearError
  };
};