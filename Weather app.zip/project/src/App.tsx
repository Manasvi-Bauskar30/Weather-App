import React, { useState } from 'react';
import { SearchForm } from './components/SearchForm';
import { WeatherCard } from './components/WeatherCard';
import { LoadingSpinner } from './components/LoadingSpinner';
import { ErrorMessage } from './components/ErrorMessage';
import { useWeather } from './hooks/useWeather';
import { Cloud, Sun, CloudRain } from 'lucide-react';

function App() {
  const { weather, loading, error, recentSearches, searchWeather, clearError } = useWeather();
  const [unit, setUnit] = useState<'C' | 'F'>('C');

  const handleUnitToggle = () => {
    setUnit(unit === 'C' ? 'F' : 'C');
  };

  const handleRetry = () => {
    clearError();
    if (weather) {
      searchWeather(weather.name);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-400 via-blue-500 to-blue-600 flex flex-col items-center justify-center p-4">
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <Cloud className="absolute top-10 left-10 text-white/20 w-16 h-16 animate-float" />
        <Sun className="absolute top-20 right-20 text-yellow-300/30 w-12 h-12 animate-pulse" />
        <CloudRain className="absolute bottom-20 left-20 text-white/20 w-14 h-14 animate-float-delayed" />
      </div>

      <div className="relative z-10 flex flex-col items-center w-full max-w-2xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-2 drop-shadow-lg">
            Weather App
          </h1>
          <p className="text-blue-100 text-lg">
            Get real-time weather information for any city
          </p>
        </div>

        {/* Search Form */}
        <SearchForm
          onSearch={searchWeather}
          isLoading={loading}
          recentSearches={recentSearches}
          onRecentSearchClick={searchWeather}
        />

        {/* Main Content */}
        <div className="w-full flex justify-center">
          {loading && <LoadingSpinner />}
          
          {error && !loading && (
            <ErrorMessage 
              message={error.message} 
              onRetry={weather ? handleRetry : undefined}
            />
          )}
          
          {weather && !loading && !error && (
            <WeatherCard 
              weather={weather} 
              unit={unit}
              onUnitToggle={handleUnitToggle}
            />
          )}
          
          {!weather && !loading && !error && (
            <div className="text-center text-white/80 max-w-md">
              <Cloud className="w-20 h-20 mx-auto mb-4 opacity-50" />
              <h2 className="text-2xl font-semibold mb-2">Welcome to Weather App</h2>
              <p className="text-lg">
                Enter a city name above to get started with real-time weather information.
              </p>
              <div className="mt-6 p-4 bg-yellow-500/20 rounded-lg border border-yellow-400/30">
                <p className="text-sm">
                  <strong>Note:</strong> You'll need to add your OpenWeatherMap API key to make this app work. 
                  Check the weatherService.ts file for instructions.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="absolute bottom-4 text-center text-white/60 text-sm">
        <p>Powered by OpenWeatherMap API</p>
      </div>

      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
        @keyframes float-delayed {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-15px); }
        }
        .animate-float {
          animation: float 6s ease-in-out infinite;
        }
        .animate-float-delayed {
          animation: float-delayed 8s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}

export default App;