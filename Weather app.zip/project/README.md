# Simple Weather App (No API Required)

A beautiful, responsive weather application built with pure HTML, CSS, and JavaScript. This demo version uses sample weather data, so no API key is required!

## Features

- 🌤️ Sample weather data for 10+ popular cities
- 🌡️ Temperature display with Celsius/Fahrenheit toggle
- 🔍 City search with recent searches history
- 📱 Fully responsive design for all devices
- 💨 Weather details (humidity, wind speed, feels like temperature)
- 🎨 Beautiful gradient backgrounds with floating animations
- ⚡ Fast loading with smooth transitions
- 🌐 Clean, modern UI with intuitive navigation
- 🔄 Error handling for unsupported cities

## Available Cities

Try searching for any of these cities:
- London
- New York
- Tokyo
- Paris
- Sydney
- Mumbai
- Berlin
- Moscow
- Dubai
- Singapore

## Getting Started

1. Download all project files
2. Open `index.html` in your web browser
3. Start searching for cities!

No setup required - it works immediately!

## File Structure

```
├── index.html          # Main HTML structure
├── style.css           # All styling and responsive design
├── script.js           # JavaScript functionality with sample data
└── README.md           # Project documentation
```

## Features Breakdown

### Responsive Design
- Mobile-first approach
- Tablet optimization (768px+)
- Desktop enhancements (1024px+)
- Touch-friendly interface elements

### Visual Elements
- Gradient backgrounds
- Floating cloud animations
- Smooth transitions and hover effects
- Weather emoji icons
- Glass-morphism design elements

### Functionality
- Sample weather data simulation
- Local storage for recent searches
- Temperature unit conversion
- Loading states and feedback
- Error handling for unsupported cities

## Browser Compatibility

- Chrome (recommended)
- Firefox
- Safari
- Edge
- Mobile browsers

## Customization

You can easily customize the app by modifying:

- **Colors**: Update the CSS gradient values in `style.css`
- **Cities**: Add more sample data in the `sampleWeatherData` object in `script.js`
- **Animations**: Adjust keyframe animations and transitions
- **Layout**: Modify the responsive breakpoints and grid layouts

## Demo Data

This version includes realistic weather data for demonstration purposes. Each city has:
- Temperature in Celsius
- Weather description
- Appropriate weather emoji
- Humidity percentage
- Wind speed in km/h
- "Feels like" temperature

## Converting to Real API

To convert this to use a real weather API:
1. Replace the `getWeatherData()` method with actual API calls
2. Add your API key configuration
3. Update error handling for API-specific errors
4. Modify the data formatting as needed

## Performance

- Lightweight (no external dependencies)
- Fast loading times
- Optimized animations
- Efficient local storage usage
- Minimal memory footprint

## License

This project is open source and available under the MIT License.

## Contributing

Feel free to submit issues and enhancement requests!