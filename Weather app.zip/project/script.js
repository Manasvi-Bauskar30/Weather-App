// Weather App JavaScript - Demo Version (No API Required)
class WeatherApp {
    constructor() {
        this.currentUnit = 'C';
        this.currentWeatherData = null;
        this.recentSearches = this.getRecentSearches();
        
        // Sample weather data for different cities
        this.sampleWeatherData = {
            'london': {
                name: 'London',
                country: 'UK',
                temperature: 18,
                description: 'partly cloudy',
                icon: '⛅',
                humidity: 65,
                windSpeed: 12,
                feelsLike: 20,
            },
            'new york': {
                name: 'New York',
                country: 'US',
                temperature: 22,
                description: 'sunny',
                icon: '☀️',
                humidity: 45,
                windSpeed: 8,
                feelsLike: 25,
            },
            'tokyo': {
                name: 'Tokyo',
                country: 'JP',
                temperature: 26,
                description: 'clear sky',
                icon: '☀️',
                humidity: 70,
                windSpeed: 6,
                feelsLike: 28,
            },
            'paris': {
                name: 'Paris',
                country: 'FR',
                temperature: 16,
                description: 'light rain',
                icon: '🌧️',
                humidity: 80,
                windSpeed: 15,
                feelsLike: 14,
            },
            'sydney': {
                name: 'Sydney',
                country: 'AU',
                temperature: 24,
                description: 'partly cloudy',
                icon: '⛅',
                humidity: 55,
                windSpeed: 18,
                feelsLike: 26,
            },
            'mumbai': {
                name: 'Mumbai',
                country: 'IN',
                temperature: 32,
                description: 'hot and humid',
                icon: '🌡️',
                humidity: 85,
                windSpeed: 10,
                feelsLike: 38,
            },
            'berlin': {
                name: 'Berlin',
                country: 'DE',
                temperature: 14,
                description: 'overcast',
                icon: '☁️',
                humidity: 72,
                windSpeed: 11,
                feelsLike: 12,
            },
            'moscow': {
                name: 'Moscow',
                country: 'RU',
                temperature: 8,
                description: 'snow',
                icon: '❄️',
                humidity: 90,
                windSpeed: 20,
                feelsLike: 3,
            },
            'dubai': {
                name: 'Dubai',
                country: 'AE',
                temperature: 38,
                description: 'very hot',
                icon: '🔥',
                humidity: 40,
                windSpeed: 5,
                feelsLike: 42,
            },
            'singapore': {
                name: 'Singapore',
                country: 'SG',
                temperature: 30,
                description: 'thunderstorm',
                icon: '⛈️',
                humidity: 88,
                windSpeed: 14,
                feelsLike: 35,
            }
        };
        
        this.initializeElements();
        this.bindEvents();
        this.updateRecentSearches();
    }

    initializeElements() {
        this.elements = {
            form: document.getElementById('weatherForm'),
            cityInput: document.getElementById('cityInput'),
            searchBtn: document.getElementById('searchBtn'),
            loading: document.getElementById('loading'),
            errorMessage: document.getElementById('errorMessage'),
            errorText: document.getElementById('errorText'),
            retryBtn: document.getElementById('retryBtn'),
            weatherCard: document.getElementById('weatherCard'),
            welcomeMessage: document.getElementById('welcomeMessage'),
            recentSearches: document.getElementById('recentSearches'),
            recentList: document.getElementById('recentList'),
            cityName: document.getElementById('cityName'),
            weatherDescription: document.getElementById('weatherDescription'),
            weatherIcon: document.getElementById('weatherIcon'),
            temperature: document.getElementById('temperature'),
            unitToggle: document.getElementById('unitToggle'),
            feelsLike: document.getElementById('feelsLike'),
            humidity: document.getElementById('humidity'),
            windSpeed: document.getElementById('windSpeed')
        };
    }

    bindEvents() {
        this.elements.form.addEventListener('submit', (e) => this.handleSearch(e));
        this.elements.retryBtn.addEventListener('click', () => this.handleRetry());
        this.elements.unitToggle.addEventListener('click', () => this.toggleUnit());
    }

    async handleSearch(e) {
        e.preventDefault();
        const city = this.elements.cityInput.value.trim();
        
        if (!city) return;
        
        await this.searchWeather(city);
        this.elements.cityInput.value = '';
    }

    async searchWeather(city) {
        this.showLoading();
        this.hideAllSections();
        
        try {
            // Simulate API delay
            await this.delay(1000);
            
            const weatherData = this.getWeatherData(city);
            this.currentWeatherData = weatherData;
            this.displayWeather();
            this.addToRecentSearches(city);
        } catch (error) {
            this.showError(error.message);
        } finally {
            this.hideLoading();
        }
    }

    getWeatherData(city) {
        const cityKey = city.toLowerCase();
        
        // Check if we have sample data for this city
        if (this.sampleWeatherData[cityKey]) {
            return this.sampleWeatherData[cityKey];
        }
        
        // If city not found in sample data, throw error
        throw new Error(`Weather data not available for "${city}". Try: London, New York, Tokyo, Paris, Sydney, Mumbai, Berlin, Moscow, Dubai, or Singapore.`);
    }

    displayWeather() {
        const weather = this.currentWeatherData;
        
        this.elements.cityName.textContent = `${weather.name}, ${weather.country}`;
        this.elements.weatherDescription.textContent = weather.description;
        this.elements.weatherIcon.textContent = weather.icon;
        this.elements.humidity.textContent = `${weather.humidity}%`;
        this.elements.windSpeed.textContent = `${weather.windSpeed} km/h`;
        
        this.updateTemperatureDisplay();
        this.showWeatherCard();
    }

    updateTemperatureDisplay() {
        const weather = this.currentWeatherData;
        const temp = this.convertTemperature(weather.temperature);
        const feelsLike = this.convertTemperature(weather.feelsLike);
        
        this.elements.temperature.textContent = temp;
        this.elements.feelsLike.textContent = `${feelsLike}°${this.currentUnit}`;
        this.elements.unitToggle.textContent = `°${this.currentUnit}`;
    }

    convertTemperature(temp) {
        if (this.currentUnit === 'F') {
            return Math.round((temp * 9/5) + 32);
        }
        return temp;
    }

    toggleUnit() {
        this.currentUnit = this.currentUnit === 'C' ? 'F' : 'C';
        if (this.currentWeatherData) {
            this.updateTemperatureDisplay();
        }
    }

    addToRecentSearches(city) {
        // Remove if already exists
        this.recentSearches = this.recentSearches.filter(search => 
            search.toLowerCase() !== city.toLowerCase()
        );
        
        // Add to beginning
        this.recentSearches.unshift(city);
        
        // Keep only last 5
        this.recentSearches = this.recentSearches.slice(0, 5);
        
        // Save to localStorage
        localStorage.setItem('weather-recent-searches', JSON.stringify(this.recentSearches));
        
        this.updateRecentSearches();
    }

    getRecentSearches() {
        const saved = localStorage.getItem('weather-recent-searches');
        return saved ? JSON.parse(saved) : [];
    }

    updateRecentSearches() {
        if (this.recentSearches.length === 0) {
            this.elements.recentSearches.style.display = 'none';
            return;
        }

        this.elements.recentList.innerHTML = '';
        this.recentSearches.forEach(search => {
            const button = document.createElement('button');
            button.className = 'recent-item';
            button.textContent = search;
            button.addEventListener('click', () => this.searchWeather(search));
            this.elements.recentList.appendChild(button);
        });

        this.elements.recentSearches.style.display = 'block';
    }

    handleRetry() {
        if (this.currentWeatherData) {
            this.searchWeather(this.currentWeatherData.name);
        }
    }

    showLoading() {
        this.elements.loading.style.display = 'flex';
        this.elements.searchBtn.disabled = true;
    }

    hideLoading() {
        this.elements.loading.style.display = 'none';
        this.elements.searchBtn.disabled = false;
    }

    showError(message) {
        this.elements.errorText.textContent = message;
        this.elements.errorMessage.style.display = 'block';
        this.elements.welcomeMessage.style.display = 'none';
    }

    showWeatherCard() {
        this.elements.weatherCard.style.display = 'block';
        this.elements.welcomeMessage.style.display = 'none';
    }

    hideAllSections() {
        this.elements.errorMessage.style.display = 'none';
        this.elements.weatherCard.style.display = 'none';
        this.elements.welcomeMessage.style.display = 'none';
    }

    // Utility function to simulate API delay
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new WeatherApp();
});

// Add entrance animations
document.addEventListener('DOMContentLoaded', () => {
    const elements = document.querySelectorAll('.header, .search-container, .welcome-message');
    elements.forEach((el, index) => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        
        setTimeout(() => {
            el.style.opacity = '1';
            el.style.transform = 'translateY(0)';
        }, index * 200);
    });
});